const NotFound = () => {
    return <div className="centered">
        <p>404. Page Not Found!</p>
    </div>
}
export default NotFound;